<main class="catalog  mb ">     
            <div class="boxleft">
            <div class="box_title">SẢN PHẨM </div>
            <div class="items">
             <div class="box_items">
               <div class="box_items_img">
                  <img src="img/realme2.jpg" alt="">
                  <div class="add" href="">ADD TO CART</div>
               </div>
                <a class="item_name" href="">SamSung J4</a>
                <p class="price">$4000</p>
                
             </div>
             <div class="box_items">
               <div class="box_items_img">
                  <img src="img/iphoneX.jpg" alt="">
                  <div class="add" href="">ADD TO CART</div>
               </div>
                <a class="item_name" href="">SamSung J4</a>
                <p class="price">$4000</p>
                
             </div>
             <div class="box_items">
               <div class="box_items_img">
                  <img src="img/iphoneX.jpg" alt="">
                  <div class="add" href="">ADD TO CART</div>
               </div>
                <a class="item_name" href="">SamSung J4</a>
                <p class="price">$4000</p>
                
             </div>
             <div class="box_items">
               <div class="box_items_img">
                  <img src="img/item1.jpg" alt="">
                  <div class="add" href="">ADD TO CART</div>
               </div>
                <a class="item_name" href="">SamSung J4</a>
                <p class="price">$4000</p>
                
             </div>
             <div class="box_items">
               <div class="box_items_img">
                  <img src="img/item0.jfif" alt="">
                  <div class="add" href="">ADD TO CART</div>
               </div>
                <a class="item_name" href="">SamSung J4</a>
                <p class="price">$4000</p>
                
             </div>
             <div class="box_items">
               <div class="box_items_img">
                  <img src="img/galaxyJ4.jfif" alt="">
                  <div class="add" href="">ADD TO CART</div>
               </div>
                <a class="item_name" href="">SamSung J4</a>
                <p class="price">$4000</p>
                
             </div>
             <div class="box_items">
               <div class="box_items_img">
                  <img src="img/iphoneX.jpg" alt="">
                  <a class="add" href="">ADD TO CART</a>
               </div>
                <a class="item_name" href="">SamSung J4</a>
                <p class="price">$4000</p>
                
             </div>
             <div class="box_items">
               <div class="box_items_img">
                  <img src="img/item0.jfif" alt="">
                  <div class="add" href="">ADD TO CART</div>
               </div>
                <a class="item_name" href="">SamSung J4</a>
                <p class="price">$4000</p>
                
             </div>
             <div class="box_items">
               <div class="box_items_img">
                  <img src="img/anh5.jpg" alt="">
                  <div class="add" ><a href="danhsach.html">ADD TO CART</a></div>
               </div>
                <a class="item_name" href="">SamSung J4</a>
                <p class="price">$4000</p>
                
             </div>
             
             
            
        </div>
      </div>
      <?php
         include "view/boxright.php";
        ?> 
</main>