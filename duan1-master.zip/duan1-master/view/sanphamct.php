<main class="catalog  mb ">

<div class="boxleft">
  <div class="  mb">
    <div class="box_title">CHI TIẾT SẢN PHẨM</div>
    <div class="box_content">
      <img src="img/iphoneX.jpg">
    </div>
  </div>

  <div class="mb">
    <div class="box_title">BÌNH LUẬN</div>
    <div class="box_content2  product_portfolio binhluan ">
      <table>
        <tr>
          <td>Sản phẩm quá đẹp</td>
          <td>Nguyễn Thành A</td>
          <td>20/10/2022</td>
        </tr>
        <tr>
          <td>Sản phẩm quá đẹp</td>
          <td>Nguyễn Thành A</td>
          <td>20/10/2022</td>
        </tr>
      </table>
    </div>
    <div class="box_search">
      <form action method="POST">
        <input type="hidden" name="idpro" value>
        <input type="text" name="noidung">
        <input type="submit" name="guibinhluan"
          value="Gửi bình luận">
      </form>
    </div>

  </div>

  <div class=" mb">
    <div class="box_title">SẢN PHẨM CÙNG LOẠI</div>
    <div class="box_content">
      <li><a href>Sản phẩm 1</a></li>
      <li><a href>Sản phẩm 1</a></li>
      <li><a href>Sản phẩm 1</a></li>
      <li><a href>Sản phẩm 1</a></li>
      <li><a href>Sản phẩm 1</a></li>
    </div>
  </div>
</div>
      <?php
         include "view/boxright.php";
      ?>

</main>